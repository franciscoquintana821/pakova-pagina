/* =============================================================================
   SECCIÓN CURSOS · Pakova
   -----------------------------------------------------------------------------
   Arma las tarjetas de la sección Cursos. El botón "Ver el curso" lleva
   a la página de detalle de cada curso (ver CONFIG.paginaDelCurso).

   Índice del archivo:
     1. Configuración general
     2. Datos de los cursos          ← lo que más se edita
     3. Íconos
     4. Utilidades
     5. Componentes compartidos
     6. Tarjetas de la sección
     7. Carrusel y abanico
     8. Animación de entrada
     9. Inicio
   ========================================================================== */

/* -----------------------------------------------------------------------------
   TILDES, Ñ Y SIGNOS ¿ ¡
   -----------------------------------------------------------------------------
   Dentro de los textos, las tildes y la ñ están escritas como \u00e1, \u00f1,
   \u00bf, etc. (escapes de JavaScript). Así se ven siempre bien, aunque el
   servidor que publica el sitio no avise que este archivo está en UTF-8.
   Si escribís textos nuevos, guardá este archivo en UTF-8; y si ves algo como
   "AprendÃ©", mirá la nota de encoding en cursos.html.
   -------------------------------------------------------------------------- */


/* =============================================================================
   1. CONFIGURACIÓN GENERAL
   ========================================================================== */

const CONFIG = {
  // Código de país + área + número, sin "+" ni espacios
  whatsapp: '5493416206812',
  email: 'pakovatesting@gmail.com',

  // Se muestra en todos los cursos
  costo: 'Gratuito',

  // Dirección de la página de detalle de cada curso (la arma otra persona
  // del equipo). Por defecto: cursos/<id>.html, por ejemplo
  // cursos/testing-qa-manual.html. Si un curso tiene "pagina", se usa esa.
  paginaDelCurso: (curso) => curso.pagina || `cursos/${curso.id}.html`,

  // Mensajes que se escriben solos en WhatsApp
  mensajes: {
    curso: (nombre) =>
      `Hola Pakova, quiero informaci\u00f3n sobre el curso de ${nombre}`,
    proximos:
      'Hola Pakova, quiero que me avisen cuando abran los pr\u00f3ximos cursos'
  }
};


/* =============================================================================
   2. DATOS DE LOS CURSOS
   -----------------------------------------------------------------------------
   Para agregar un curso: copiá un bloque { ... } completo y cambiá
   los textos.

   Campos:
     id           Único, en minúsculas, sin espacios ni tildes (va en el link
                  a la página del curso)
     pagina       Opcional. Dirección de la página del curso, si no es la de
                  siempre (ver CONFIG.paginaDelCurso)
     nombre       Título del curso
     icono        Uno de los nombres de la sección 3 (ICONOS)
     resumen      Qué es el curso, en 1 o 2 frases simples (unos 120
                  caracteres). Va en la tarjeta
     nivel        Ej.: 'Desde cero', 'Nivel inicial'. Va arriba en la tarjeta
     estado       Opcional. Ej.: 'Inscripción abierta'. Dejar '' para ocultarlo
     temas        Lista de { titulo, texto }. En la tarjeta se muestra
                  cuántos son ("5 temas")

   Contenido para la página de detalle de cada curso (esta sección no lo
   muestra; queda acá para quien arme esas páginas):
     fechas, sede, descripcion, paraQuien, requisitos, alTerminar, preguntas
   ========================================================================== */

const CURSOS = [
  {
    id: 'testing-qa-manual',
    pagina: 'testing-qa-manual.html',
    nombre: 'Testing QA Manual',
    icono: 'lupa',
    resumen:
      'Aprend\u00e9 a revisar apps y p\u00e1ginas web para encontrar errores antes ' +
        'de que lleguen a la gente. No hace falta saber programar.',
    nivel: 'Nivel inicial',
    estado: '',
    fechas: '',
    sede: '',
    descripcion: [
      'El testing es la tarea de revisar que un programa, una app o una ' +
        'p\u00e1gina web funcione como debe antes de que llegue a las personas ' +
        'que lo usan. Quien hace testing busca errores, los documenta y ' +
        'ayuda al equipo a corregirlos.',
      'En este curso vas a conocer c\u00f3mo trabaja un equipo de QA (control ' +
        'de calidad) y vas a practicar como en un proyecto real: dise\u00f1ar ' +
        'casos de prueba, ejecutarlos y reportar los errores que ' +
        'encuentres de forma clara.'
    ],
    paraQuien: [
      'Personas que quieren dar su primer paso en el mundo tecnol\u00f3gico',
      'Quienes buscan una salida laboral en el \u00e1rea de software',
      'Personas detallistas, curiosas y con ganas de entender c\u00f3mo ' +
        'funcionan las cosas'
    ],
    temas: [
      {
        titulo: 'Fundamentos de QA',
        texto:
          'Calidad antes que nada: qu\u00e9 es la calidad de software, por qu\u00e9 ' +
          'existen los errores y cu\u00e1l es el rol del tester dentro del equipo.'
      },
      {
        titulo: 'Ciclo de vida del software',
        texto:
          'De la idea al lanzamiento: las etapas por las que pasa un ' +
          'producto y en qu\u00e9 momento entra el testing para evitar fallas ' +
          'antes de publicar.'
      },
      {
        titulo: 'Casos de prueba',
        texto:
          'Punto de partida, pasos y resultado esperado: as\u00ed se escribe un ' +
          'caso de prueba claro, con qu\u00e9 necesitamos antes de empezar, qu\u00e9 ' +
          'acciones seguir y qu\u00e9 deber\u00eda pasar.'
      },
      {
        titulo: 'Reporte de errores',
        texto:
          'Pasos, esperado y obtenido: c\u00f3mo describir un error con ' +
          'evidencia para que el equipo pueda reproducirlo y corregirlo ' +
          'sin adivinar.'
      },
      {
        titulo: 'Metodolog\u00edas \u00e1giles',
        texto:
          'Testing en cada sprint: c\u00f3mo se organizan los equipos con Scrum ' +
          'y c\u00f3mo se integra la calidad en ese ritmo de trabajo.'
      }
    ],
    requisitos: [
      'Manejo b\u00e1sico de computadora e internet',
      'No hace falta experiencia previa en tecnolog\u00eda'
    ],
    alTerminar: [
      'Entender c\u00f3mo trabaja un equipo de QA',
      'Dise\u00f1ar y ejecutar casos de prueba',
      'Reportar errores de forma clara y profesional',
      'Usar herramientas de gesti\u00f3n de pruebas'
    ],
    preguntas: [
      {
        pregunta: '\u00bfNecesito saber programar?',
        respuesta:
          'No. El testing manual no requiere programar. Si despu\u00e9s quer\u00e9s ' +
          'automatizar pruebas, Testing QA Automation es el siguiente paso.'
      }
    ]
  },
  {
    id: 'testing-qa-automation',
    pagina: 'testing-qa-automation.html',
    nombre: 'Testing QA Automation con IA',
    nombreAcento: 'con IA',
    icono: 'robot',
    resumen:
      'Aprend\u00e9 a crear programas que revisan apps y p\u00e1ginas web solos y ' +
        'avisan cuando algo falla. Es el paso siguiente al testing manual.',
    nivel: 'Nivel intermedio',
    estado: '',
    fechas: '',
    sede: '',
    descripcion: [
      'Cuando un programa crece, probarlo todo a mano lleva mucho tiempo. ' +
        'La automatizaci\u00f3n consiste en escribir pruebas que la ' +
        'computadora ejecuta sola, cada vez que hace falta, y que avisan ' +
        'si algo dej\u00f3 de funcionar.',
      'En este curso vas a dar el paso del testing manual al automatizado: ' +
        'vas a aprender a pensar qu\u00e9 conviene automatizar, a escribir tus ' +
        'primeras pruebas y a leer sus resultados.'
    ],
    paraQuien: [
      'Quienes hicieron Testing QA Manual y quieren seguir creciendo',
      'Testers que quieren sumar herramientas m\u00e1s buscadas por las empresas',
      'Personas con nociones de programaci\u00f3n que quieren aplicarlas'
    ],
    temas: [
      {
        titulo: 'Qu\u00e9 es la automatizaci\u00f3n',
        texto:
          'Para qu\u00e9 sirve, cu\u00e1ndo conviene automatizar una prueba y ' +
          'cu\u00e1ndo es mejor hacerla a mano.'
      },
      {
        titulo: 'Programaci\u00f3n para testers',
        texto:
          'Los conceptos de programaci\u00f3n que hacen falta para escribir ' +
          'pruebas, explicados paso a paso.'
      },
      {
        titulo: 'Pruebas de p\u00e1ginas web',
        texto:
          'C\u00f3mo hacer que un programa abra una p\u00e1gina, complete ' +
          'formularios y revise que todo funcione.'
      },
      {
        titulo: 'Pruebas de servicios (APIs)',
        texto:
          'C\u00f3mo probar la parte "invisible" de una aplicaci\u00f3n: los datos ' +
          'que se env\u00edan y se reciben.'
      },
      {
        titulo: 'Organizar las pruebas',
        texto:
          'C\u00f3mo ordenar las pruebas para que sean f\u00e1ciles de mantener y de ' +
          'volver a usar.'
      },
      {
        titulo: 'Reportes de resultados',
        texto:
          'C\u00f3mo leer lo que devuelven las pruebas y comunicar los errores ' +
          'al equipo.'
      }
    ],
    requisitos: [
      'Haber completado Testing QA Manual (obligatorio)',
      'Recomendable: nociones b\u00e1sicas de programaci\u00f3n'
    ],
    alTerminar: [
      'Decidir qu\u00e9 pruebas conviene automatizar',
      'Escribir pruebas autom\u00e1ticas para p\u00e1ginas web',
      'Probar servicios y datos de una aplicaci\u00f3n',
      'Leer resultados y reportar errores al equipo'
    ],
    preguntas: [
      {
        pregunta: '\u00bfNecesito saber programar?',
        respuesta:
          'Ayuda tener nociones b\u00e1sicas. Si nunca programaste, te ' +
          'recomendamos empezar por Programaci\u00f3n Web Inicial.'
      }
    ]
  },
  {
    id: 'alfabetizacion-digital',
    pagina: 'alfabetizacion-digital.html',
    nombre: 'Alfabetizaci\u00f3n Digital',
    icono: 'compu',
    resumen:
      'Tus primeros pasos con la computadora, internet y el correo ' +
        'electr\u00f3nico. Desde cero, a tu ritmo y con acompa\u00f1amiento.',
    nivel: 'Desde cero',
    estado: '',
    fechas: '',
    sede: '',
    descripcion: [
      'Hoy muchos tr\u00e1mites, trabajos y estudios dependen de saber usar una ' +
        'computadora e internet. Este curso es para dar esos primeros ' +
        'pasos con tranquilidad, a tu ritmo y con acompa\u00f1amiento.',
      'Vas a aprender a manejar la computadora, buscar informaci\u00f3n, usar ' +
        'el correo electr\u00f3nico, organizar tus archivos y escribir ' +
        'documentos, siempre cuidando tu seguridad en internet.'
    ],
    paraQuien: [
      'Personas que nunca usaron una computadora o la usan poco',
      'Quienes necesitan herramientas digitales para estudiar, trabajar o ' +
        'hacer tr\u00e1mites',
      'Adultos y adultos mayores que quieren ganar autonom\u00eda'
    ],
    temas: [
      {
        titulo: 'La computadora',
        texto:
          'Encender y apagar, usar el mouse y el teclado, abrir programas ' +
          'y moverse por las ventanas.'
      },
      {
        titulo: 'Internet',
        texto:
          'Qu\u00e9 es un navegador, c\u00f3mo buscar informaci\u00f3n y c\u00f3mo reconocer ' +
          'p\u00e1ginas confiables.'
      },
      {
        titulo: 'Correo electr\u00f3nico',
        texto:
          'Crear una cuenta, enviar y responder mails, y adjuntar archivos.'
      },
      {
        titulo: 'Archivos',
        texto:
          'Guardar, encontrar, ordenar en carpetas y descargar documentos ' +
          'e im\u00e1genes.'
      },
      {
        titulo: 'Herramientas de oficina',
        texto:
          'Escribir un documento, armar una lista o una planilla simple y ' +
          'compartirla.'
      },
      {
        titulo: 'Seguridad digital',
        texto:
          'Contrase\u00f1as seguras, c\u00f3mo reconocer estafas y enga\u00f1os, y c\u00f3mo ' +
          'cuidar tus datos personales.'
      }
    ],
    requisitos: ['Ning\u00fan conocimiento previo', 'Ganas de aprender'],
    alTerminar: [
      'Usar la computadora con confianza',
      'Buscar informaci\u00f3n y comunicarte por correo electr\u00f3nico',
      'Crear y organizar tus propios documentos',
      'Navegar por internet de forma segura'
    ],
    preguntas: [
      {
        pregunta: '\u00bfNecesito tener computadora en casa?',
        respuesta:
          'Consultanos: te contamos c\u00f3mo se organiza cada convocatoria y ' +
          'con qu\u00e9 equipos se trabaja.'
      }
    ]
  },
  {
    id: 'programacion-web-inicial',
    pagina: 'programacion-web-inicial.html',
    nombre: 'Programaci\u00f3n Web Inicial',
    icono: 'codigo',
    resumen:
      'Descubr\u00ed c\u00f3mo se hace una p\u00e1gina web por dentro y arm\u00e1 la tuya, ' +
        'paso a paso. Ideal para empezar a programar.',
    nivel: 'Nivel inicial',
    estado: '',
    fechas: '',
    sede: '',
    descripcion: [
      'Cada p\u00e1gina que visit\u00e1s est\u00e1 hecha con c\u00f3digo. En este curso vas ' +
        'a aprender c\u00f3mo se arma una p\u00e1gina web: su estructura, su ' +
        'dise\u00f1o y las primeras l\u00edneas de programaci\u00f3n que le dan vida.',
      'Vas a desarrollar el pensamiento l\u00f3gico y practicar desde la primera ' +
        'clase, hasta armar tu propia p\u00e1gina.'
    ],
    paraQuien: [
      'Personas que quieren empezar a programar desde cero',
      'Quienes quieren crear su propia p\u00e1gina o trabajar en desarrollo web',
      'Personas a las que les gusta resolver problemas y crear cosas'
    ],
    temas: [
      {
        titulo: 'C\u00f3mo funciona una p\u00e1gina web',
        texto:
          'Qu\u00e9 pasa cuando abr\u00eds un link: el navegador, el servidor y los ' +
          'archivos que forman una p\u00e1gina.'
      },
      {
        titulo: 'HTML: la estructura',
        texto:
          'T\u00edtulos, textos, im\u00e1genes y links: el esqueleto de la p\u00e1gina.'
      },
      {
        titulo: 'CSS: el dise\u00f1o',
        texto: 'Colores, tipograf\u00edas y c\u00f3mo ubicar cada cosa en la pantalla.'
      },
      {
        titulo: 'L\u00f3gica de programaci\u00f3n',
        texto:
          'Variables, condicionales y bucles, explicados con ejemplos de ' +
          'la vida diaria.'
      },
      {
        titulo: 'JavaScript b\u00e1sico',
        texto:
          'Darle vida a la p\u00e1gina: botones que responden y mensajes que ' +
          'aparecen.'
      },
      {
        titulo: 'Tu primera p\u00e1gina',
        texto: 'Juntar todo lo aprendido y armar una p\u00e1gina completa.'
      }
    ],
    requisitos: [
      'Manejo b\u00e1sico de computadora',
      'No hace falta saber matem\u00e1tica avanzada'
    ],
    alTerminar: [
      'Entender c\u00f3mo funciona una p\u00e1gina web',
      'Armar una p\u00e1gina con HTML y CSS',
      'Escribir tus primeros programas en JavaScript',
      'Seguir aprendiendo por tu cuenta o en pr\u00f3ximos cursos'
    ],
    preguntas: [
      {
        pregunta: '\u00bfNecesito ser bueno en matem\u00e1tica?',
        respuesta:
          'No. Alcanza con la l\u00f3gica del d\u00eda a d\u00eda; el curso te ayuda a ' +
          'desarrollarla.'
      }
    ]
  },
  {
    id: 'testing-qa-videojuegos',
    pagina: 'testing-qa-videojuegos.html',
    nombre: 'Testing QA de Videojuegos',
    icono: 'control',
    resumen:
      'Prob\u00e1 videojuegos como lo hace un equipo profesional: busc\u00e1 fallas ' +
        'y ayud\u00e1 a que el juego funcione bien antes de salir.',
    nivel: 'Nivel inicial',
    estado: '',
    fechas: '',
    sede: '',
    descripcion: [
      'Antes de que un videojuego salga a la venta, un equipo de testers ' +
        'lo juega una y otra vez para encontrar errores: personajes que ' +
        'atraviesan paredes, niveles que no cargan, controles que no ' +
        'responden o partes que resultan confusas.',
      'En este curso vas a aprender a jugar con mirada profesional: ' +
        'detectar fallas, evaluar la jugabilidad y el rendimiento, y ' +
        'comunicar lo que encontr\u00e1s para que el equipo de desarrollo pueda ' +
        'mejorar el juego.'
    ],
    paraQuien: [
      'Personas a las que les gustan los videojuegos y quieren conocer la ' +
        'industria por dentro',
      'Quienes ya hicieron Testing QA Manual y quieren especializarse',
      'Personas observadoras y pacientes'
    ],
    temas: [
      {
        titulo: 'An\u00e1lisis de bugs',
        texto:
          'Tipos de errores en videojuegos (gr\u00e1ficos, de l\u00f3gica, de ' +
          'sonido, de colisiones) y c\u00f3mo reproducirlos y documentarlos.'
      },
      {
        titulo: 'Jugabilidad',
        texto:
          'C\u00f3mo evaluar si un juego se entiende, si los controles ' +
          'responden bien y si la dificultad est\u00e1 equilibrada.'
      },
      {
        titulo: 'Rendimiento',
        texto:
          'Qu\u00e9 mirar cuando un juego se traba, tarda en cargar o baja la ' +
          'cantidad de cuadros por segundo.'
      },
      {
        titulo: 'Experiencia de usuario',
        texto:
          'C\u00f3mo detectar partes confusas, men\u00fas dif\u00edciles de usar o ' +
          'momentos que frustran a quien juega.'
      },
      {
        titulo: 'Compatibilidad',
        texto:
          'Por qu\u00e9 un juego puede funcionar bien en un equipo y mal en ' +
          'otro, y c\u00f3mo se prueba en distintos dispositivos.'
      }
    ],
    requisitos: [
      'Manejo b\u00e1sico de computadora',
      'Recomendable (no obligatorio): haber hecho Testing QA Manual'
    ],
    alTerminar: [
      'Probar un videojuego de forma ordenada',
      'Detectar y clasificar distintos tipos de errores',
      'Escribir reportes que el equipo de desarrollo pueda usar',
      'Dar opiniones fundamentadas sobre jugabilidad y experiencia'
    ],
    preguntas: [
      {
        pregunta: '\u00bfTengo que ser gamer?',
        respuesta:
          'No hace falta, pero s\u00ed ganas de jugar con atenci\u00f3n y probar las ' +
          'cosas muchas veces.'
      }
    ]
  },
  {
    id: 'english-for-qa',
    pagina: 'english-for-qa.html',
    nombre: 'English for QA',
    icono: 'globo',
    resumen:
      'Ingl\u00e9s t\u00e9cnico para trabajar en QA: vocabulario, reportes de errores ' +
        'y reuniones. Ideal para sumarte a equipos internacionales.',
    nivel: 'Nivel inicial',
    estado: '',
    fechas: '',
    sede: '',
    descripcion: [
      'Muchos equipos de calidad trabajan en ingl\u00e9s: los reportes de ' +
        'errores, las historias de usuario, las reuniones diarias y las ' +
        'entrevistas laborales suelen estar en ese idioma.',
      'En este curso vas a aprender el ingl\u00e9s espec\u00edfico del testing: el ' +
        'vocabulario que se usa todos los d\u00edas y las formas de escribir y ' +
        'hablar para que te entiendan dentro de un equipo de QA.'
    ],
    paraQuien: [
      'Testers que quieren trabajar en equipos o empresas internacionales',
      'Personas con ingl\u00e9s b\u00e1sico que necesitan usarlo en el trabajo',
      'Quienes ya hacen QA y quieren comunicarse con m\u00e1s seguridad'
    ],
    temas: [
      {
        titulo: 'Vocabulario de QA',
        texto:
          'Las palabras que aparecen todo el tiempo: bug, test case, ' +
          'regression, release, sprint y acceptance criteria.'
      },
      {
        titulo: 'Reportar errores en ingl\u00e9s',
        texto:
          'C\u00f3mo escribir un reporte claro: pasos, resultado esperado, ' +
          'resultado obtenido y evidencia.'
      },
      {
        titulo: 'Leer tickets y documentaci\u00f3n',
        texto:
          'C\u00f3mo entender historias de usuario, criterios de aceptaci\u00f3n y ' +
          'notas de una versi\u00f3n.'
      },
      {
        titulo: 'Reuniones y standups',
        texto:
          'Frases para contar qu\u00e9 hiciste, qu\u00e9 vas a hacer y qu\u00e9 te est\u00e1 ' +
          'bloqueando en una reuni\u00f3n diaria.'
      },
      {
        titulo: 'Comunicaci\u00f3n diaria',
        texto:
          'Mensajes por chat, correos y llamadas breves con el equipo de ' +
          'desarrollo y otras \u00e1reas.'
      },
      {
        titulo: 'Entrevistas y primer d\u00eda',
        texto:
          'Preguntas frecuentes en una entrevista de QA y vocabulario para ' +
          'empezar a trabajar en un equipo en ingl\u00e9s.'
      }
    ],
    requisitos: [
      'Conocimientos b\u00e1sicos de ingl\u00e9s (lectura y escritura)',
      'Manejo b\u00e1sico de computadora',
      'Recomendable: estar haciendo o haber hecho un curso de QA'
    ],
    alTerminar: [
      'Entender y escribir reportes de errores en ingl\u00e9s',
      'Leer tickets y documentaci\u00f3n de un proyecto',
      'Participar en reuniones y standups con seguridad',
      'Prepararte para entrevistas de QA en ingl\u00e9s'
    ],
    preguntas: [
      {
        pregunta: '\u00bfNecesito tener un ingl\u00e9s avanzado?',
        respuesta:
          'No. El curso parte de una base b\u00e1sica y se enfoca en el ingl\u00e9s ' +
          'que se usa en QA. Si te cuesta leer o escribir, te recomendamos ' +
          'practicar un poco antes de empezar.'
      },
      {
        pregunta: '\u00bfEs un curso de ingl\u00e9s general?',
        respuesta:
          'No. Es ingl\u00e9s aplicado al trabajo de QA: vocabulario, reportes, ' +
          'reuniones y entrevistas. No reemplaza un curso general de idioma.'
      }
    ]
  }
];

// Cursos que vienen: se muestran en la cinta de "Próximamente"
const PROXIMOS = [
  {
    sigla: 'IA',
    nombre: 'Testing con inteligencia artificial',
    imagen: '../img/proximo-ia.svg'
  },
  {
    sigla: 'PY',
    nombre: 'Python para automatizaci\u00f3n',
    imagen: '../img/proximo-python.svg'
  },
  {
    sigla: 'JV',
    nombre: 'Java con Spring Boot',
    imagen: '../img/proximo-java.svg'
  }
];


/* =============================================================================
   3. ÍCONOS
   -----------------------------------------------------------------------------
   Cada ícono es una lista de trazos SVG (atributo "d" de <path>), en una
   cuadrícula de 24×24. Para sumar uno, agregá una línea más con su nombre.
   ========================================================================== */

const ICONOS = {
  // Íconos de cursos (todos con el mismo estilo: trazo simple, sin relleno)
  lupa: [
    'M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14Z',
    'm20 20-4-4',
    'm8 11 2 2 4-4'
  ],
  control: [
    'M7 8h10a5 5 0 0 1 0 10H7A5 5 0 0 1 7 8Z',
    'M8 11v4M6 13h4',
    'M15.5 12h.01M17.5 14h.01'
  ],
  compu: [
    'M5 5h14a1 1 0 0 1 1 1v10H4V6a1 1 0 0 1 1-1Z',
    'M2 19h20',
    'M10 9l3 2-3 2Z'
  ],
  codigo: ['m8 8-4 4 4 4', 'm16 8 4 4-4 4', 'm13.5 6-3 12'],
  robot: [
    'M7 9h10a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2Z',
    'M12 9V5M12 5h.01',
    'M9.5 13h.01M14.5 13h.01M10 16h4'
  ],
  libro: [
    'M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2V5Z',
    'M4 19a2 2 0 0 1 2-2h13'
  ],
  globo: [
    'M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Z',
    'M3 12h18',
    'M12 3c3.5 3 3.5 15 0 18',
    'M12 3c-3.5 3-3.5 15 0 18'
  ],

  // Íconos de interfaz
  abrir: ['M4 12h14M13 6l6 6-6 6']
};


/* =============================================================================
   4. UTILIDADES
   ========================================================================== */

/** Evita que un texto con < > & " rompa el HTML. Usar SIEMPRE con datos. */
function esc(texto) {
  return String(texto ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** Une una lista de textos HTML en uno solo. */
function unir(lista, funcion) {
  return lista.map(funcion).join('');
}

/** Link de WhatsApp para consultar por un curso (o con otro mensaje). */
function linkWhatsApp(mensaje) {
  const texto = encodeURIComponent(mensaje);
  return `https://wa.me/${CONFIG.whatsapp}?text=${texto}`;
}

function linkConsulta(curso) {
  return linkWhatsApp(CONFIG.mensajes.curso(curso.nombre));
}


/* =============================================================================
   5. COMPONENTES COMPARTIDOS
   Piezas que usan las tarjetas.
   ========================================================================== */

/** Ícono SVG. */
function icono(nombre) {
  const trazos = ICONOS[nombre] || ICONOS.libro;
  const paths = unir(trazos, (d) => `<path d="${d}"/>`);

  return `
    <svg class="pk-svg" viewBox="0 0 24 24" aria-hidden="true">
      ${paths}
    </svg>`;
}

/** Cuadrado amarillo con el ícono del curso. */
function cajaIcono(nombre) {
  return `<span class="pk-icon">${icono(nombre)}</span>`;
}

/** Datos rápidos: "Gratuito · 5 temas". */
function datosRapidos(curso) {
  const items = [CONFIG.costo, `${curso.temas.length} temas`];

  return `
    <ul class="pk-dots">
      ${unir(items, (texto) => `<li>${esc(texto)}</li>`)}
    </ul>`;
}

/** Etiqueta con el nivel del curso ("Desde cero", "Nivel inicial"). */
function etiquetaNivel(curso) {
  if (!curso.nivel) return '';
  return `<span class="pk-level">${esc(curso.nivel)}</span>`;
}

/** Etiqueta amarilla de estado (solo si el curso tiene estado). */
function etiquetaEstado(curso) {
  if (!curso.estado) return '';
  return `<span class="pk-status">${esc(curso.estado)}</span>`;
}

/** Link a WhatsApp con forma de botón. Variante: '' o 'ghost'. */
function botonWhatsApp(curso, texto, variante = '') {
  const clase = variante ? `pk-btn pk-btn--${variante}` : 'pk-btn';

  return `
    <a
      class="${clase}"
      href="${linkConsulta(curso)}"
      target="_blank"
      rel="noopener"
    >
      ${texto}
    </a>`;
}


/* =============================================================================
   6. TARJETAS DE LA SECCIÓN
   ========================================================================== */

/*
  La variable --orden hace que las tarjetas aparezcan de a una
  (ver "Animación de entrada" en cursos.css).
*/
/**
 * Título de la tarjeta. Si el curso define "nombreAcento", esa parte
 * final del nombre se muestra como una etiqueta amarilla para destacarla.
 */
function tituloCurso(curso) {
  const nombre = esc(curso.nombre);
  const acento = curso.nombreAcento ? esc(curso.nombreAcento) : '';

  if (!acento || !nombre.endsWith(acento)) return nombre;

  return (
    nombre.slice(0, -acento.length).trimEnd() +
    `<span class="pk-course__title-accent">${acento}</span>`
  );
}

function tarjetaCurso(curso, indice) {
  return `
    <article class="pk-card pk-course" style="--orden: ${indice}">
      <div class="pk-course__top">
        ${cajaIcono(curso.icono)}
        ${etiquetaNivel(curso)}
      </div>

      ${etiquetaEstado(curso)}

      <h3
        class="pk-course__title"${curso.nombreAcento ? ` aria-label="${esc(curso.nombre)}"` : ''}
      >${tituloCurso(curso)}</h3>
      <p class="pk-course__text">${esc(curso.resumen)}</p>
      ${datosRapidos(curso)}

      <div class="pk-actions">
        <a class="pk-btn" href="${esc(CONFIG.paginaDelCurso(curso))}">
          Ver el curso ${icono('abrir')}
        </a>
        ${botonWhatsApp(curso, 'Consultar', 'ghost')}
      </div>
    </article>`;
}

function itemProximo(item) {
  return `
    <li>
      <span class="pk-ticker__media">
        <img
          class="pk-ticker__img"
          src="${esc(item.imagen)}"
          alt=""
          width="480"
          height="300"
          loading="lazy"
        >
        <span class="pk-next__code">${esc(item.sigla)}</span>
      </span>
      <span class="pk-ticker__info">
        <span class="pk-ticker__name">${esc(item.nombre)}</span>
        <span class="pk-ticker__soon">Muy pronto</span>
      </span>
    </li>`;
}

function mostrarTarjetas() {
  const grilla = document.getElementById('pk-lista');
  const proximos = document.getElementById('pk-proximos');
  const listaProximos = document.getElementById('pk-proximos-lista');
  const botonProximos = document.getElementById('pk-proximos-boton');

  grilla.innerHTML = unir(CURSOS, tarjetaCurso);

  if (PROXIMOS.length === 0) {
    proximos.hidden = true;
    return;
  }

  listaProximos.innerHTML = unir(PROXIMOS, itemProximo);
  botonProximos.href = linkWhatsApp(CONFIG.mensajes.proximos);
  iniciarCarruselProximos();
}


/* ---------- Próximos cursos: cinta automática ----------
   La cinta y su movimiento están en cursos.css (sección 5). Acá se arma
   la copia de la lista y se calcula la velocidad.
*/

// Velocidad de la cinta, en píxeles por segundo (más alto = más rápido)
const VELOCIDAD_PROXIMOS = 32;

/**
 * La animación dura lo que tarda en pasar una lista entera a esta
 * velocidad. Así se mueve igual de rápido en celular y en compu, y
 * aunque se agreguen o saquen cursos.
 */
function ajustarVelocidadProximos() {
  const carrusel = document.getElementById('pk-proximos-carrusel');
  const ancho = document.getElementById('pk-proximos-lista').offsetWidth;

  carrusel.style.setProperty(
    '--pk-duracion',
    `${Math.max(ancho / VELOCIDAD_PROXIMOS, 10)}s`
  );
}

function iniciarCarruselProximos() {
  const lista = document.getElementById('pk-proximos-lista');
  const copia = document.getElementById('pk-proximos-copia');

  copia.innerHTML = lista.innerHTML;

  // Recalcula la velocidad si cambia el ancho (girar el celular, etc.)
  ajustarVelocidadProximos();
  if ('ResizeObserver' in window) {
    new ResizeObserver(ajustarVelocidadProximos).observe(lista);
  }
}


/* =============================================================================
   7. CARRUSEL Y ABANICO
   -----------------------------------------------------------------------------
   Las tarjetas se muestran como carrusel (celular, tablet, pantallas
   táctiles) o como abanico (computadora con mouse y pantalla grande).
   El dibujo de cada forma está en cursos.css (sección 4). Acá se maneja
   lo que comparten las dos: cuál es la tarjeta "activa" y cómo se pasa
   de una a otra (flechas, puntitos, teclado, deslizar, arrastrar o clic).

   7.1  Estado y ayudas
   7.2  Cambiar la tarjeta activa
   7.3  Puntitos, flechas, contador y pista
   7.4  Escuchar flechas, clics, teclado, arrastre y deslizamiento
   ========================================================================== */

/* ---------- 7.1 Estado y ayudas ---------- */

// Misma condición que el abanico en cursos.css (sección 4.4)
const MODO_ABANICO = window.matchMedia(
  '(min-width: 1360px) and (hover: hover) and (pointer: fine)'
);

const SIN_MOVIMIENTO = window.matchMedia('(prefers-reduced-motion: reduce)');

// Índice de la tarjeta que está al frente (abanico) o al centro (carrusel)
let tarjetaActiva = 0;

// Textos de la pista según cómo se ve la sección
const PISTAS = {
  abanico: 'Hac\u00e9 clic en una tarjeta o us\u00e1 las flechas para ver m\u00e1s cursos',
  carrusel: 'Desliz\u00e1 con el dedo para ver m\u00e1s cursos'
};

function listaDeTarjetas() {
  return [...document.querySelectorAll('.pk-course')];
}

function esAbanico() {
  return MODO_ABANICO.matches;
}


/* ---------- 7.2 Cambiar la tarjeta activa ---------- */

/**
 * Acomoda un grupo de tarjetas en abanico alrededor de la "activa".
 * A cada tarjeta le pone la clase "pk-activa", su --lugar y su z-index.
 */
function ubicarEnAbanico(tarjetas, activa) {
  const total = tarjetas.length;
  const mitad = Math.floor(total / 2);

  tarjetas.forEach((tarjeta, i) => {
    // Lugar en el abanico contando desde la activa, que queda en el centro
    // (0). Las demás se reparten en ronda a los dos lados. En el abanico
    // se muestran solo 5 posiciones (-2 a 2): la tarjeta más lejana queda
    // oculta hasta que el abanico gira.
    const lugar = (((i - activa) % total) + total + mitad) % total - mitad;
    const lugarAnterior = Number(tarjeta.dataset.lugar);

    // La tarjeta que pasa de una punta a la otra (tendría que cruzar más
    // de medio abanico) no se arrastra por delante: salta directo a su
    // nuevo lugar, por detrás de las demás.
    const salta =
      tarjeta.dataset.lugar !== undefined &&
      Math.abs(lugar - lugarAnterior) > mitad;
    if (salta) tarjeta.classList.add('pk-salto');

    // En el abanico se muestran solo 5 posiciones: las tarjetas que
    // quedarían más lejos se ocultan y vuelven a aparecer al girar.
    tarjeta.classList.toggle('pk-oculta', esAbanico() && Math.abs(lugar) > 2);

    tarjeta.classList.toggle('pk-activa', i === activa);
    tarjeta.style.setProperty('--lugar', lugar);
    tarjeta.style.zIndex = total - Math.abs(lugar);
    tarjeta.dataset.lugar = lugar;

    // De qué lado de la activa está (para el cartel "Clic para ver")
    tarjeta.dataset.lado = lugar < 0 ? 'izq' : 'der';

    if (salta) {
      void tarjeta.offsetWidth;   // aplica el salto antes de volver a animar
      requestAnimationFrame(() => tarjeta.classList.remove('pk-salto'));
    }
  });
}

/**
 * Marca una tarjeta de curso como activa y actualiza puntitos y flechas.
 */
function marcarActiva(indice) {
  const tarjetas = listaDeTarjetas();

  tarjetaActiva = Math.max(0, Math.min(tarjetas.length - 1, indice));
  ubicarEnAbanico(tarjetas, tarjetaActiva);

  actualizarPuntitos();
  actualizarFlechas(tarjetas.length);
}

/**
 * La primera vez que la persona pasa de tarjeta, se apagan las ayudas
 * (la flecha que late y la pista de abajo). Ver cursos.css, 4.5.
 */
function marcarUsado() {
  document.getElementById('pk-slider').classList.add('pk-slider--usado');
}

/** Marca la tarjeta y, en el carrusel, la desliza hasta el centro. */
function irATarjeta(indice) {
  marcarActiva(indice);
  if (esAbanico()) return;

  const grilla = document.getElementById('pk-lista');
  const tarjeta = listaDeTarjetas()[tarjetaActiva];
  const izquierda =
    tarjeta.offsetLeft - (grilla.clientWidth - tarjeta.offsetWidth) / 2;

  grilla.scrollTo({
    left: izquierda,
    behavior: SIN_MOVIMIENTO.matches ? 'auto' : 'smooth'
  });
}

/** En el carrusel: la tarjeta más cercana al centro pasa a ser la activa. */
function activarLaDelCentro() {
  if (esAbanico()) return;

  const grilla = document.getElementById('pk-lista');
  const centroGrilla = grilla.scrollLeft + grilla.clientWidth / 2;
  const distancias = listaDeTarjetas().map((tarjeta) =>
    Math.abs(tarjeta.offsetLeft + tarjeta.offsetWidth / 2 - centroGrilla)
  );

  const masCercana = distancias.indexOf(Math.min(...distancias));
  if (masCercana !== tarjetaActiva) marcarUsado();

  marcarActiva(masCercana);
}


/* ---------- 7.3 Puntitos, flechas, contador y pista ---------- */

function crearPuntitos() {
  const puntitos = document.getElementById('pk-puntitos');

  puntitos.innerHTML = unir(CURSOS, (curso, i) => `
    <button
      type="button"
      data-ir="${i}"
      aria-label="Ver ${esc(curso.nombre)}"
    ></button>`);
}

function actualizarPuntitos() {
  document.querySelectorAll('#pk-puntitos button').forEach((punto, i) => {
    punto.setAttribute('aria-current', String(i === tarjetaActiva));
  });
}

/**
 * Las flechas nunca se apagan: en la última tarjeta, "siguiente" vuelve
 * a la primera, y en la primera, "anterior" va a la última (ver 7.4).
 * El texto para lectores de pantalla avisa cuando se da la vuelta.
 */
function actualizarFlechas(total) {
  const anterior = document.querySelector('.pk-slider__arrow--prev');
  const siguiente = document.querySelector('.pk-slider__arrow--next');
  const contador = document.getElementById('pk-contador');

  anterior.setAttribute(
    'aria-label',
    tarjetaActiva === 0 ? 'Ir al \u00faltimo curso' : 'Curso anterior'
  );
  siguiente.setAttribute(
    'aria-label',
    tarjetaActiva === total - 1 ? 'Volver al primer curso' : 'Curso siguiente'
  );
  contador.textContent = `Curso ${tarjetaActiva + 1} de ${total}`;
}

function actualizarPista() {
  const texto = document.getElementById('pk-pista-texto');
  texto.textContent = esAbanico() ? PISTAS.abanico : PISTAS.carrusel;
}


/* ---------- 7.4 Escuchar flechas, clics, teclado y deslizamiento ---------- */

/** Pasa de tarjeta por una acción de la persona (no al cargar la página). */
function moverPorLaPersona(indice) {
  marcarUsado();
  irATarjeta(indice);
}

// Tiempo mínimo entre un paso y otro, casi lo que tarda el abanico en
// girar (transform 0.42s en cursos.css, 4.1). Así responde rápido sin
// encadenar giros a lo loco.
const PAUSA_ENTRE_PASOS = 380;
let ultimoPaso = 0;

/**
 * Avanza (paso = 1) o retrocede (paso = -1) dando la vuelta:
 * después de la última viene la primera, y antes de la primera, la última.
 *
 * Dos frenos para que no gire "a lo loco":
 *  - Los pedidos que llegan mientras el abanico todavía está girando se
 *    ignoran (clics muy rápidos, tecla apretada).
 *  - Si la persona deja una tecla apretada (repetido = true), avanza hasta
 *    la última tarjeta y ahí se detiene. Para volver a la 1ª hay que soltar
 *    y apretar otra vez.
 */
function moverEnRonda(paso, repetido = false) {
  const ahora = performance.now();
  if (ahora - ultimoPaso < PAUSA_ENTRE_PASOS) return;

  const total = listaDeTarjetas().length;
  const destino = tarjetaActiva + paso;
  const daLaVuelta = destino < 0 || destino >= total;
  if (daLaVuelta && repetido) return;

  ultimoPaso = ahora;
  moverPorLaPersona((destino + total) % total);
}

function escucharTarjetas() {
  const slider = document.getElementById('pk-slider');
  const grilla = document.getElementById('pk-lista');
  let esperaDeslizar;
  let inicioArrastre = null;
  let recienArrastrado = false;

  // Clic en una tarjeta
  grilla.addEventListener('click', (evento) => {
    const tarjeta = evento.target.closest('.pk-course');
    if (!tarjeta) return;

    // El clic que llega al soltar un arrastre no abre ningún link
    if (recienArrastrado) {
      evento.preventDefault();
      return;
    }

    const indice = listaDeTarjetas().indexOf(tarjeta);

    // Los botones de la tarjeta ("Ver el curso", "Consultar") funcionan
    // al primer clic, aunque la tarjeta esté de costado. Antes había que
    // traerla al frente con un clic y recién después se abría el curso.
    if (evento.target.closest('.pk-actions a, .pk-actions button')) {
      marcarUsado();
      return;
    }

    // Si es una tarjeta de costado, primero se trae al frente.
    // En la activa, el resto de los links funciona normalmente.
    if (indice !== tarjetaActiva) {
      evento.preventDefault();
      moverPorLaPersona(indice);
    }
  });

  // Flechas y puntitos
  slider.addEventListener('click', (evento) => {
    const flecha = evento.target.closest('[data-mover]');
    const punto = evento.target.closest('[data-ir]');

    if (flecha) moverEnRonda(Number(flecha.dataset.mover));
    if (punto) moverPorLaPersona(Number(punto.dataset.ir));
  });

  // Enter apretado sobre una flecha de la pantalla repite el clic solo:
  // se deja pasar solo el primero (soltar y apretar de nuevo para seguir)
  slider.addEventListener('keydown', (evento) => {
    if (evento.repeat && evento.target.closest('[data-mover]')) {
      evento.preventDefault();
    }
  });

  // Flechas del teclado (cuando la grilla tiene el foco).
  // evento.repeat = la tecla quedó apretada (ver moverEnRonda).
  grilla.addEventListener('keydown', (evento) => {
    if (evento.key === 'ArrowLeft') moverEnRonda(-1, evento.repeat);
    if (evento.key === 'ArrowRight') moverEnRonda(1, evento.repeat);
  });

  // Abanico: arrastrar con el mouse hacia un lado pasa de tarjeta
  grilla.addEventListener('pointerdown', (evento) => {
    if (esAbanico()) inicioArrastre = evento.clientX;
  });

  grilla.addEventListener('pointerup', (evento) => {
    if (inicioArrastre === null) return;

    const recorrido = evento.clientX - inicioArrastre;
    inicioArrastre = null;
    if (Math.abs(recorrido) < 50) return;   // fue un clic, no un arrastre

    // Arrastrar a la izquierda muestra la siguiente (como en el celular)
    moverEnRonda(recorrido < 0 ? 1 : -1);

    // Evita que el clic que llega después del arrastre abra algo
    recienArrastrado = true;
    setTimeout(() => (recienArrastrado = false), 0);
  });

  // Deslizar con el dedo en el carrusel: espera a que frene
  grilla.addEventListener('scroll', () => {
    clearTimeout(esperaDeslizar);
    esperaDeslizar = setTimeout(activarLaDelCentro, 80);
  });

  // Si cambia el modo (ej.: se agranda la ventana), se reacomoda
  MODO_ABANICO.addEventListener('change', () => {
    actualizarPista();
    irATarjeta(tarjetaActiva);
  });
}

function iniciarCarruselYAbanico() {
  crearPuntitos();
  actualizarPista();
  escucharTarjetas();

  // El abanico y el carrusel arrancan con la primera tarjeta al frente.
  // En el abanico, las demás se reparten en las 5 posiciones visibles.
  const inicial = 0;
  irATarjeta(inicial);
}


/* =============================================================================
   8. ANIMACIÓN DE ENTRADA
   -----------------------------------------------------------------------------
   Cuando la sección aparece en pantalla, le agrega la clase "pk-visible" a
   la grilla y las tarjetas suben de a una. El movimiento está en cursos.css.
   ========================================================================== */

function animarAlAparecer() {
  const grilla = document.getElementById('pk-lista');

  // Navegadores viejos: se muestran directo, sin animación
  if (!('IntersectionObserver' in window)) {
    grilla.classList.add('pk-visible');
    return;
  }

  const observador = new IntersectionObserver((entradas) => {
    if (!entradas[0].isIntersecting) return;
    grilla.classList.add('pk-visible');
    observador.disconnect();
  }, { threshold: 0.15 });

  observador.observe(grilla);
}


/* =============================================================================
    9. INICIO
   ========================================================================== */

function iniciarCursos() {
  mostrarTarjetas();
  iniciarCarruselYAbanico();
  animarAlAparecer();
}

document.addEventListener('DOMContentLoaded', iniciarCursos);
