/* ==========================================================================
   ROADMAP DE CURSOS · Dibuja las "patitas" entre los recuadros
   Las líneas se calculan según dónde quedó cada recuadro, así sirven igual
   en computadora, tablet y celular. Se conectan paso a paso al verse.
   ========================================================================== */

(function () {
  var red = document.querySelector(".red");
  if (!red) return;

  var NS = "http://www.w3.org/2000/svg";
  var svg = document.createElementNS(NS, "svg");
  svg.setAttribute("class", "red__lineas");
  svg.setAttribute("aria-hidden", "true");
  red.insertBefore(svg, red.firstChild);

  var animar =
    "IntersectionObserver" in window &&
    !window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function caja(nombre) {
    var e = red.querySelector('[data-nodo="' + nombre + '"]');
    var x = e.offsetLeft;
    var y = e.offsetTop;
    var w = e.offsetWidth;
    var h = e.offsetHeight;
    return { x: x, y: y, w: w, h: h, cx: x + w / 2, cy: y + h / 2, r: x + w, b: y + h };
  }

  /* Línea quebrada con las esquinas redondeadas, como los brazos del logo */
  function trazo(p) {
    var d = "M" + p[0][0] + " " + p[0][1];
    for (var i = 1; i < p.length - 1; i++) {
      var a = p[i - 1], v = p[i], b = p[i + 1];
      var la = Math.hypot(v[0] - a[0], v[1] - a[1]);
      var lb = Math.hypot(b[0] - v[0], b[1] - v[1]);
      var r = Math.min(14, la / 2, lb / 2);
      if (!r) continue;
      d +=
        " L" + (v[0] - ((v[0] - a[0]) / la) * r) + " " + (v[1] - ((v[1] - a[1]) / la) * r) +
        " Q" + v[0] + " " + v[1] + " " +
        (v[0] + ((b[0] - v[0]) / lb) * r) + " " + (v[1] + ((b[1] - v[1]) / lb) * r);
    }
    var f = p[p.length - 1];
    return d + " L" + f[0] + " " + f[1];
  }

  function crear(tipo, clase, atributos, paso) {
    var e = document.createElementNS(NS, tipo);
    e.setAttribute("class", clase);
    for (var k in atributos) e.setAttribute(k, atributos[k]);
    e.style.setProperty("--paso", paso + "s");
    svg.appendChild(e);
  }

  function dibujar() {
    var logo = caja("logo"), alfa = caja("alfa"), prog = caja("prog"),
      manual = caja("manual"), auto = caja("auto"), juego = caja("juego"),
      ingles = caja("ingles");
    var ancha = window.matchMedia("(min-width: 900px)").matches;
    var lineas = []; // [puntos, paso, amarilla, nodoInicio, nodoFin]

    if (ancha) {
      var m1 = (alfa.r + prog.x) / 2;
      var m2 = (manual.r + juego.x) / 2;
      lineas.push([[[logo.r, logo.cy], [alfa.x, alfa.cy]], 0.2, false, true, true]);
      lineas.push([[[alfa.r, alfa.cy], [m1, alfa.cy], [m1, prog.cy], [prog.x, prog.cy]], 1, false, true, true]);
      lineas.push([[[alfa.r, alfa.cy], [m1, alfa.cy], [m1, manual.cy], [manual.x, manual.cy]], 1, false, false, true]);
      /* Programación y QA Manual se juntan y desembocan en Automation */
      lineas.push([[[prog.cx, prog.b], [prog.cx, auto.cy]], 2.2, true, true, false]);
      lineas.push([[[manual.cx, manual.y], [manual.cx, auto.cy]], 2.2, true, true, false]);
      lineas.push([[[prog.cx, auto.cy], [auto.x, auto.cy]], 2.8, true, false, true]);
      /* Dos patas más salen de QA Manual */
      lineas.push([[[manual.r, manual.cy], [juego.x, juego.cy]], 3.7, false, true, true]);
      lineas.push([[[manual.r, manual.cy], [m2, manual.cy], [m2, ingles.cy], [ingles.x, ingles.cy]], 3.7, false, false, true]);
    } else {
      var y1 = (alfa.b + prog.y) / 2;
      var y2 = (Math.max(prog.b, manual.b) + auto.y) / 2;
      var lomo = juego.x - 14;
      lineas.push([[[logo.cx, logo.b], [alfa.cx, alfa.y]], 0.2, false, true, true]);
      lineas.push([[[alfa.cx, alfa.b], [alfa.cx, y1], [prog.cx, y1], [prog.cx, prog.y]], 1, false, true, true]);
      lineas.push([[[alfa.cx, alfa.b], [alfa.cx, y1], [manual.cx, y1], [manual.cx, manual.y]], 1, false, false, true]);
      lineas.push([[[prog.cx, prog.b], [prog.cx, y2]], 2.2, true, true, false]);
      lineas.push([[[manual.x + 18, manual.b], [manual.x + 18, y2], [prog.cx, y2]], 2.2, true, true, false]);
      lineas.push([[[prog.cx, y2], [auto.cx, auto.y]], 2.8, true, false, true]);
      lineas.push([[[lomo, manual.b], [lomo, juego.cy], [juego.x, juego.cy]], 3.7, false, true, true]);
      lineas.push([[[lomo, manual.b], [lomo, ingles.cy], [ingles.x, ingles.cy]], 3.7, false, false, true]);
    }

    svg.textContent = "";
    svg.setAttribute("viewBox", "0 0 " + red.clientWidth + " " + red.clientHeight);

    lineas.forEach(function (l) {
      var color = l[2] ? " es-amarilla" : "";
      var d = trazo(l[0]);
      crear("path", "pata" + color, { d: d, pathLength: 1 }, l[1]);
      crear("path", "destello" + color, { d: d }, l[1] + 0.6);
    });
    lineas.forEach(function (l) {
      var color = l[2] ? " es-amarilla" : "";
      var a = l[0][0], b = l[0][l[0].length - 1];
      if (l[3]) crear("circle", "nodo" + color, { cx: a[0], cy: a[1], r: 6 }, l[1]);
      if (l[4]) crear("circle", "nodo" + color, { cx: b[0], cy: b[1], r: 6 }, l[1] + 0.5);
    });
  }

  dibujar();
  window.addEventListener("resize", dibujar);
  window.addEventListener("load", dibujar);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(dibujar);

  if (animar) {
    red.classList.add("red--espera");
    var observador = new IntersectionObserver(
      function (entradas) {
        if (!entradas[0].isIntersecting) return;
        dibujar();
        red.classList.replace("red--espera", "red--conectando");
        observador.disconnect();
        /* Terminada la secuencia, quedan solo los destellos */
        window.setTimeout(function () {
          red.classList.replace("red--conectando", "red--lista");
        }, 5600);
      },
      { threshold: 0.35 }
    );
    observador.observe(red);
  }
})();
