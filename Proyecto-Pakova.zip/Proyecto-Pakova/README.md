# Proyecto Pakova

Sitio web de cursos de Pakova (HTML, CSS y JavaScript).

- `html/cursos.html` — página principal (abrir `index.html` redirige ahí)
- `html/`, `css/`, `js/` — una página, hoja de estilos y script por curso
- `img/`, `fonts/` — recursos
- `docs/` — documentación del código
- `francisco-diseno/` — borradores de diseño
